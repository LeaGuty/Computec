/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;



/**
 *
 * @author lgutierrez
 */
public class Laptop extends Equipo  {
    private double pantalla;
    private boolean esTactil;
    private int puertosUsb;

    public Laptop(int id, String modelo, String cpu, int discoDuro, int ram, double precio, double pantalla, boolean esTactil, int puertosUsb) {
        super(id, modelo, cpu, discoDuro, ram, precio);
        this.pantalla = pantalla;
        this.esTactil = esTactil;
        this.puertosUsb = puertosUsb;
    }
    
    

    // Getters y Setters
    public double getPantalla() { return pantalla; }
    public void setPantalla(double pantalla) { this.pantalla = pantalla; }

    public boolean isEsTactil() { return esTactil; }
    public void setEsTactil(boolean esTactil) { this.esTactil = esTactil; }

    public int getPuertosUsb() { return puertosUsb; }
    public void setPuertosUsb(int puertosUsb) { this.puertosUsb = puertosUsb; }
    
    @Override
    public double calcularPrecio() {
        return getPrecio();
    }
}
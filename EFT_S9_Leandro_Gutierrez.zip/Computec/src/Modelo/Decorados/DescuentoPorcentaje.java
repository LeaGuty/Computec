/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo.Decorados;

/**
 *
 * @author lgutierrez
 */
public class DescuentoPorcentaje extends Decorator {
    private  Double porcentaje;
    
    public DescuentoPorcentaje(Component componenteDecorado, Double porcentaje) {
        super(componenteDecorado);
        this.porcentaje = porcentaje;
    }
     @Override
    public double calcularPrecio() {
        return componenteDecorado.calcularPrecio() * (1 - porcentaje / 100);
    }
  
}
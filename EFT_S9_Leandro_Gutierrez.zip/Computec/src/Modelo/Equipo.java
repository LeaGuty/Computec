/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

import Modelo.Decorados.Component;

/**
 *
 * @author lgutierrez
 */
public abstract class Equipo implements Component{
    private int id;
    private String modelo;
    private String cpu;
    private int discoDuro;
    private int ram;
    private double precio;

    public Equipo(int id, String modelo, String cpu, int discoDuro, int ram, double precio) {
        this.id = id;
        this.modelo = modelo;
        this.cpu = cpu;
        this.discoDuro = discoDuro;
        this.ram = ram;
        this.precio = precio;
    }

    // Getters y Setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public String getModelo() { return modelo; }
    public void setModelo(String modelo) { this.modelo = modelo; }

    public String getCpu() { return cpu; }
    public void setCpu(String cpu) { this.cpu = cpu; }

    public int getDiscoDuro() { return discoDuro; }
    public void setDiscoDuro(int discoDuro) { this.discoDuro = discoDuro; }

    public int getRam() { return ram; }
    public void setRam(int ram) { this.ram = ram; }

    public double getPrecio() { return precio; }
    public void setPrecio(double precio) { this.precio = precio; }
    
       @Override
    public double calcularPrecio() {
        return getPrecio();
    }
    
}

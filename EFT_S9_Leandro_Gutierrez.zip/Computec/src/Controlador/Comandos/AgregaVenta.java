/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controlador.Comandos;

import Controlador.Command;
import Controlador.ControladorVentas;
import Modelo.Venta;

/**
 *
 * @author lgutierrez
 */
public class AgregaVenta implements Command{
    private ControladorVentas controlaventa = new ControladorVentas();
    private Venta venta;

    public AgregaVenta(Venta venta) {
        this.venta = venta;
    }
    
    
    @Override
    public void ejecutar() {
        controlaventa.agregarVenta(venta);
    }
    
}

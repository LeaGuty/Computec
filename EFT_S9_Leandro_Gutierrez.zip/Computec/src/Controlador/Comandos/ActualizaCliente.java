/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controlador.Comandos;

import Controlador.Command;
import Controlador.ControladorClientes;
import Modelo.Cliente;

/**
 *
 * @author lgutierrez
 */
public class ActualizaCliente implements Command{
    private ControladorClientes control = new ControladorClientes();
    private Cliente cliente ;

    public ActualizaCliente(Cliente cliente) {
        this.cliente = cliente;
    }
    
    
    
    
    @Override
    public void ejecutar() {
        control.actualizarCliente(cliente);
    }
    
}

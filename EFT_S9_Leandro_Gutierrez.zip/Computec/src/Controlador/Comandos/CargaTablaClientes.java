/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controlador.Comandos;

import Controlador.*;
import javax.swing.JTable;
/**
 *
 * @author lgutierrez
 */
public class CargaTablaClientes implements Command{

    private ControladorClientes controladorClientes;
    private JTable tablaClientes;
    private String filtro;

    public CargaTablaClientes(ControladorClientes controladorClientes, JTable tablaClientes, String filtro) {
        this.controladorClientes = controladorClientes;
        this.tablaClientes = tablaClientes;
        this.filtro = filtro;
    }

    public void setTablaClientes(JTable tablaClientes) {
        this.tablaClientes = tablaClientes;
    }

    public void setFiltro(String filtro) {
        this.filtro = filtro;
    }
    
    
    @Override
    public void ejecutar() {
        controladorClientes.cargarClientesEnTabla(tablaClientes, filtro);
    }
    
}

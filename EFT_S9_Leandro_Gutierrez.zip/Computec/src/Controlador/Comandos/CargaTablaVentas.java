/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controlador.Comandos;

import Controlador.Command;
import Controlador.ControladorVentas;
import javax.swing.JTable;
/**
 *
 * @author lgutierrez
 */
public class CargaTablaVentas implements Command{
    private JTable tabla;
    private ControladorVentas controlaventa = new ControladorVentas();
    private String filtro;

    public CargaTablaVentas(JTable tabla, String filtro) {
        this.tabla = tabla;
        this.filtro = filtro;
    }

    
    
    
    
    
    @Override
    public void ejecutar() {
        controlaventa.mostrarVentasEnTabla(tabla, filtro);
    }
    
}

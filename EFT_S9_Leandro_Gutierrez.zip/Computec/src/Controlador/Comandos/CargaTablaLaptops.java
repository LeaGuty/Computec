/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controlador.Comandos;

import Controlador.Command;
import Controlador.ControladorEquipos;
import javax.swing.JTable;

/**
 *
 * @author lgutierrez
 */
public class CargaTablaLaptops implements Command{
    
    private ControladorEquipos controladorequipos;
    private JTable tabla;
    private String filtro;    

    public CargaTablaLaptops(ControladorEquipos controladorequipos, JTable tabla, String filtro) {
        this.controladorequipos = controladorequipos;
        this.tabla = tabla;
        this.filtro = filtro;
    }
    public void setTabla(JTable tabla) {
        this.tabla = tabla;
    }    
    
    @Override
    public void ejecutar() {
        controladorequipos.cargarLaptopsEnTabla(tabla, filtro);
    }

    
    
}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controlador.Comandos;

import Controlador.Command;
import Controlador.ControladorClientes;

/**
 *
 * @author lgutierrez
 */
public class EliminaCliente implements Command{
    private ControladorClientes controlCli = new ControladorClientes();
    private String rut_cli;

    public EliminaCliente(String rut_cli) {
        this.rut_cli = rut_cli;
    }
    
    
    @Override
    public void ejecutar() {
        controlCli.eliminarCliente(rut_cli);
    }
    
}

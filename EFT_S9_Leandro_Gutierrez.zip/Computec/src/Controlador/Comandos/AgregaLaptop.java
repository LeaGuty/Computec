/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controlador.Comandos;

import Controlador.Command;
import Controlador.ControladorEquipos;
import Modelo.Laptop;

/**
 *
 * @author lgutierrez
 */
public class AgregaLaptop implements Command{
    private ControladorEquipos controlequipo ;
    private Laptop laptop;

    public AgregaLaptop(ControladorEquipos controlequipo, Laptop laptop) {
        this.controlequipo = controlequipo;
        this.laptop = laptop;
    }
    
    
    
    
    
    @Override
    public void ejecutar() {
        controlequipo.agregarLaptop(laptop);
    }
    
}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controlador.Comandos;

import Controlador.Command;
import Controlador.ControladorEquipos;
import Modelo.Desktop;

/**
 *
 * @author lgutierrez
 */
public class AgregaDesktop implements Command{
      private ControladorEquipos controlequipo ;
      private Desktop desktop;

    public AgregaDesktop(ControladorEquipos controlequipo, Desktop desktop) {
        this.controlequipo = controlequipo;
        this.desktop = desktop;
    }
      
    
    
    @Override
    public void ejecutar() {
        controlequipo.agregarDesktop(desktop);
    }
    
}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controlador;

import Modelo.DatabaseConnection;
import Modelo.Venta;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.ResultSet;
import java.time.LocalDateTime;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

public class ControladorVentas {

    public boolean agregarVenta(Venta venta) {
        String query = "INSERT INTO Ventas (rut_cliente, id_equipo, fecha_venta, monto) VALUES (?, ?, ?, ?)";
        try (Connection connection = DatabaseConnection.getInstance().getConnection();
             PreparedStatement statement = connection.prepareStatement(query))
 {

            // Asignar los valores a los placeholders de la consulta usando el objeto Laptop
            statement.setString(1, venta.getRutCliente());
            statement.setInt(2, venta.getIdEquipo());
            statement.setString(3, venta.getFechaVenta().toString());
            statement.setDouble(4, venta.getMonto());

            // Ejecutar la consulta
            int rowsInserted = statement.executeUpdate();

            // Mostrar mensaje de �xito si la venta se registr� correctamente
            if (rowsInserted > 0) {
                JOptionPane.showMessageDialog(null, "Venta registrada correctamente", "�xito", JOptionPane.INFORMATION_MESSAGE);
            }

            return rowsInserted > 0;

        } catch (SQLException ex) {
            ex.printStackTrace();
            return false;
        }
    }
    
        public void mostrarVentasEnTabla(JTable tablaVentas, String filtro) {
        DefaultTableModel modeloTabla = (DefaultTableModel) tablaVentas.getModel();
        modeloTabla.setRowCount(0); // Limpiar la tabla

        String query = "SELECT v.id_venta, e.modelo, c.nombre_completo, c.telefono, c.email, v.monto, v.fecha_venta " +
                       "FROM Ventas v " +
                       "JOIN Clientes c ON v.rut_cliente = c.rut " +
                       "JOIN Equipos e ON v.id_equipo = e.id_equipo " +
                       "WHERE c.nombre_completo LIKE ? OR e.modelo LIKE ? OR c.telefono LIKE ? OR c.email LIKE ?" +
                       " ORDER BY v.id_venta"; 

        try (Connection connection = DatabaseConnection.getInstance().getConnection();
             PreparedStatement statement = connection.prepareStatement(query)) {

            statement.setString(1, "%" + filtro + "%");
            statement.setString(2, "%" + filtro + "%");
            statement.setString(3, "%" + filtro + "%");
            statement.setString(4, "%" + filtro + "%");

            ResultSet resultSet = statement.executeQuery();

            while (resultSet.next()) {
                int idVenta = resultSet.getInt("id_venta");
                String modelo = resultSet.getString("modelo");
                String nombreCliente = resultSet.getString("nombre_completo");
                String telefono = resultSet.getString("telefono");
                String email = resultSet.getString("email");
                double monto = resultSet.getDouble("monto");
                String fecha = resultSet.getString("fecha_venta");
                modeloTabla.addRow(new Object[]{idVenta, modelo, nombreCliente, telefono, email, monto,fecha});
            }

        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error al obtener las ventas: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

}
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controlador;

import Modelo.Cliente;
import Modelo.DatabaseConnection;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import javax.swing.table.DefaultTableModel;
import javax.swing.JTable;

public class ControladorClientes {
    
    public boolean agregarCliente(Cliente cliente) {
        String query = "INSERT INTO Clientes (rut, nombre_completo, direccion, email, telefono) VALUES (?, ?, ?, ?, ?)";
        
        try (Connection connection = DatabaseConnection.getInstance().getConnection();
             PreparedStatement statement = connection.prepareStatement(query)) {
            
            // Asignar los valores a la consulta
            statement.setString(1, cliente.getRut());
            statement.setString(2, cliente.getNombreCompleto());
            statement.setString(3, cliente.getDireccion());
            statement.setString(4, cliente.getEmail());
            statement.setString(5, cliente.getTelefono());

            // Ejecutar la consulta
            int rowsInserted = statement.executeUpdate();
            
            // Si se inserta una fila, devolver true
            return rowsInserted > 0;
        } catch (SQLException ex) {
            ex.printStackTrace();
            return false;
        }
    }
    
    
    public boolean eliminarCliente(String rut) {
        String query = "DELETE FROM Clientes WHERE rut = ?";

        try (Connection connection = DatabaseConnection.getInstance().getConnection();
             PreparedStatement statement = connection.prepareStatement(query)) {
            
            // Asignar el valor del rut al placeholder de la consulta
            statement.setString(1, rut);

            // Ejecutar la consulta
            int rowsDeleted = statement.executeUpdate();
            
            // Si se elimina una fila, devolver true
            return rowsDeleted > 0;
        } catch (SQLException ex) {
            ex.printStackTrace();
            return false;
        }
    }
    
    
    public boolean actualizarCliente(Cliente cliente) {
        String query = "UPDATE Clientes SET nombre_completo = ?, direccion = ?, email = ?, telefono = ? WHERE rut = ?";

        try (Connection connection = DatabaseConnection.getInstance().getConnection();
             PreparedStatement statement = connection.prepareStatement(query)) {

            // Asignar los valores a los placeholders de la consulta
            statement.setString(1, cliente.getNombreCompleto());
            statement.setString(2, cliente.getDireccion());
            statement.setString(3, cliente.getEmail());
            statement.setString(4, cliente.getTelefono());
            statement.setString(5, cliente.getRut()); // Identificar cliente por su rut

            // Ejecutar la consulta
            int rowsUpdated = statement.executeUpdate();

            // Si se actualiza una fila, devolver true
            return rowsUpdated > 0;
        } catch (SQLException ex) {
            ex.printStackTrace();
            return false;
        }
    }
    
    
    // M�todo para obtener la lista de clientes desde la base de datos
    public List<Cliente> obtenerClientes(String filtro) {
    List<Cliente> listaClientes = new ArrayList<>();
    Connection connection = null;
    PreparedStatement statement = null;
    ResultSet resultSet = null;

    try {
        connection = DatabaseConnection.getInstance().getConnection();

        // Crear la consulta SQL con filtro
        String query = "SELECT * FROM Clientes WHERE rut LIKE ? OR nombre_completo LIKE ? OR direccion LIKE ? OR email LIKE ? OR telefono LIKE ?";
        statement = connection.prepareStatement(query);
        statement.setString(1, "%" + filtro + "%");
        statement.setString(2, "%" + filtro + "%");
        statement.setString(3, "%" + filtro + "%");
        statement.setString(4, "%" + filtro + "%");
        statement.setString(5, "%" + filtro + "%");
        

        resultSet = statement.executeQuery();

        // Procesar los resultados
        while (resultSet.next()) {
            String rut = resultSet.getString("rut");
            String nombre = resultSet.getString("nombre_completo");
            String direccion = resultSet.getString("direccion");
            String email = resultSet.getString("email");
            String telefono = resultSet.getString("telefono");

            Cliente cliente = new Cliente(rut, nombre, direccion, email, telefono);
            listaClientes.add(cliente);
        }

    } catch (SQLException e) {
        e.printStackTrace();
    } finally {
        // Cerrar recursos
        try {
            if (resultSet != null) resultSet.close();
            if (statement != null) statement.close();
            if (connection != null) connection.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    return listaClientes;
}
 public void cargarClientesEnTabla(JTable table, String filtro) {

    // Subclase de DefaultTableModel para hacer la tabla no editable
    class NoEditableTableModel extends DefaultTableModel {
        @Override
        public boolean isCellEditable(int row, int column) {
            return false;
        }
    }

    NoEditableTableModel model = new NoEditableTableModel();
    model.addColumn("Rut");
    model.addColumn("Nombre");
    model.addColumn("Direcci�n");
    model.addColumn("Email");
    model.addColumn("Tel�fono");

    List<Cliente> clientes = obtenerClientes(filtro); // Usar el filtro

    for (Cliente cliente : clientes) {
        Object[] row = new Object[5];
        row[0] = cliente.getRut();
        row[1] = cliente.getNombreCompleto();
        row[2] = cliente.getDireccion();
        row[3] = cliente.getEmail();
        row[4] = cliente.getTelefono();
        model.addRow(row);
    }

    table.setModel(model);
}

}
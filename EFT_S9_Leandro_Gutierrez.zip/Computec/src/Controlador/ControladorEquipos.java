/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controlador;

import Modelo.DatabaseConnection;
import Modelo.Desktop;
import Modelo.Equipo;
import Modelo.Laptop;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

public class ControladorEquipos {

    // M�todo para agregar un laptop a la base de datos
 public boolean agregarLaptop(Laptop laptop) {
    String query = "INSERT INTO Equipos (modelo, cpu, disco_duro, ram, precio, categoria, pantalla, es_tactil, puertos_usb) " +
                   "VALUES (?, ?, ?, ?, ?, 'laptop', ?, ?, ?)";
    try (Connection connection = DatabaseConnection.getInstance().getConnection();
         PreparedStatement statement = connection.prepareStatement(query)) {

        // Asignar los valores a los placeholders de la consulta usando el objeto Laptop
        statement.setString(1, laptop.getModelo());
        statement.setString(2, laptop.getCpu());
        statement.setInt(3, laptop.getDiscoDuro());
        statement.setInt(4, laptop.getRam());
        statement.setDouble(5, laptop.getPrecio());
        statement.setDouble(6, laptop.getPantalla());
        statement.setBoolean(7, laptop.isEsTactil());
        statement.setInt(8, laptop.getPuertosUsb());

        // Ejecutar la consulta
        int rowsInserted = statement.executeUpdate();
        return rowsInserted > 0;
    } catch (SQLException ex) {
        ex.printStackTrace();
        return false;
    }
}

    // M�todo para agregar un desktop a la base de datos
public boolean agregarDesktop(Desktop desktop) {
    String query = "INSERT INTO Equipos (modelo, cpu, disco_duro, ram, precio, categoria, potencia_fuente, factor_forma) " +
                   "VALUES (?, ?, ?, ?, ?, 'desktop', ?, ?)";
    try (Connection connection = DatabaseConnection.getInstance().getConnection();
         PreparedStatement statement = connection.prepareStatement(query)) {

        // Asignar los valores a los placeholders de la consulta usando el objeto Desktop
        statement.setString(1, desktop.getModelo());
        statement.setString(2, desktop.getCpu());
        statement.setInt(3, desktop.getDiscoDuro());
        statement.setInt(4, desktop.getRam());
        statement.setDouble(5, desktop.getPrecio());
        statement.setInt(6, desktop.getPotenciaFuente());
        statement.setString(7, desktop.getFactorForma());

        // Ejecutar la consulta
        int rowsInserted = statement.executeUpdate();
        return rowsInserted > 0;
    } catch (SQLException ex) {
        ex.printStackTrace();
        return false;
    }
}

    // M�todo para actualizar un laptop en la base de datos
    public boolean actualizarLaptop(int idEquipo, String modelo, String cpu, int discoDuro, int ram, double precio, 
                                    double pantalla, boolean esTactil, int puertosUsb) {
        String query = "UPDATE Equipos SET modelo = ?, cpu = ?, disco_duro = ?, ram = ?, precio = ?, pantalla = ?, es_tactil = ?, puertos_usb = ? " +
                       "WHERE id_equipo = ? AND categoria = 'laptop'";
        try (Connection connection = DatabaseConnection.getInstance().getConnection();
             PreparedStatement statement = connection.prepareStatement(query)) {

            // Asignar los valores a los placeholders de la consulta
            statement.setString(1, modelo);
            statement.setString(2, cpu);
            statement.setInt(3, discoDuro);
            statement.setInt(4, ram);
            statement.setDouble(5, precio);
            statement.setDouble(6, pantalla);
            statement.setBoolean(7, esTactil);
            statement.setInt(8, puertosUsb);
            statement.setInt(9, idEquipo);

            // Ejecutar la consulta
            int rowsUpdated = statement.executeUpdate();
            return rowsUpdated > 0;
        } catch (SQLException ex) {
            ex.printStackTrace();
            return false;
        }
    }

    // M�todo para actualizar un desktop en la base de datos
    public boolean actualizarDesktop(int idEquipo, String modelo, String cpu, int discoDuro, int ram, double precio, 
                                     int potenciaFuente, String factorForma) {
        String query = "UPDATE Equipos SET modelo = ?, cpu = ?, disco_duro = ?, ram = ?, precio = ?, potencia_fuente = ?, factor_forma = ? " +
                       "WHERE id_equipo = ? AND categoria = 'desktop'";
        try (Connection connection = DatabaseConnection.getInstance().getConnection();
             PreparedStatement statement = connection.prepareStatement(query)) {

            // Asignar los valores a los placeholders de la consulta
            statement.setString(1, modelo);
            statement.setString(2, cpu);
            statement.setInt(3, discoDuro);
            statement.setInt(4, ram);
            statement.setDouble(5, precio);
            statement.setInt(6, potenciaFuente);
            statement.setString(7, factorForma);
            statement.setInt(8, idEquipo);

            // Ejecutar la consulta
            int rowsUpdated = statement.executeUpdate();
            return rowsUpdated > 0;
        } catch (SQLException ex) {
            ex.printStackTrace();
            return false;
        }
    }

    // M�todo para eliminar un equipo de la base de datos
    public boolean eliminarEquipo(int idEquipo) {
        String query = "DELETE FROM Equipos WHERE id_equipo = ?";
        try (Connection connection = DatabaseConnection.getInstance().getConnection();
             PreparedStatement statement = connection.prepareStatement(query)) {

            // Asignar el id del equipo al placeholder de la consulta
            statement.setInt(1, idEquipo);

            // Ejecutar la consulta
            int rowsDeleted = statement.executeUpdate();
            return rowsDeleted > 0;
        } catch (SQLException ex) {
            ex.printStackTrace();
            return false;
        }
    }
    
    public List<Laptop> obtenerLaptops(String filtro) {
        List<Laptop> listaLaptops = new ArrayList<>();
        Connection connection = null;
        PreparedStatement statement = null;
        ResultSet resultSet = null;

        try {
            connection = DatabaseConnection.getInstance().getConnection();

            // Crear la consulta SQL con filtro
            String query = "SELECT * FROM Equipos WHERE categoria = 'laptop' AND (id_equipo LIKE ? OR modelo LIKE ? OR cpu LIKE ? OR disco_duro LIKE ? OR ram LIKE ?)";
            statement = connection.prepareStatement(query);
            statement.setString(1, "%" + filtro + "%");
            statement.setString(2, "%" + filtro + "%");
            statement.setString(3, "%" + filtro + "%");
            statement.setString(4, "%" + filtro + "%");
            statement.setString(5, "%" + filtro + "%");

            resultSet = statement.executeQuery();

            // Procesar los resultados
            while (resultSet.next()) {
                int idEquipo = resultSet.getInt("id_equipo");
                String modelo = resultSet.getString("modelo");
                String cpu = resultSet.getString("cpu");
                int discoDuro = resultSet.getInt("disco_duro");
                int ram = resultSet.getInt("ram");
                double pantalla = resultSet.getDouble("pantalla");
                boolean esTactil = resultSet.getBoolean("es_tactil");
                int puertosUsb = resultSet.getInt("puertos_usb");
                double precio = resultSet.getDouble("precio");

                // public Laptop(int id, String modelo, String cpu, int discoDuro, int ram, double precio, double pantalla, boolean esTactil, int puertosUsb)
                
                Laptop laptop = new Laptop(idEquipo, modelo, cpu, discoDuro, ram, precio, pantalla, esTactil, puertosUsb);
                listaLaptops.add(laptop);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            // Cerrar recursos
            try {
                if (resultSet != null) resultSet.close();
                if (statement != null) statement.close();
                if (connection != null) connection.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return listaLaptops;
    }
    public List<Desktop> obtenerDesktops(String filtro) {
        List<Desktop> listaDesktops = new ArrayList<>();
        Connection connection = null;
        PreparedStatement statement = null;
        ResultSet resultSet = null;

        try {
            connection = DatabaseConnection.getInstance().getConnection();

            // Crear la consulta SQL con filtro
            String query = "SELECT * FROM Equipos WHERE categoria = 'desktop' AND (modelo LIKE ? OR cpu LIKE ?)";
            statement = connection.prepareStatement(query);
            statement.setString(1, "%" + filtro + "%");
            statement.setString(2, "%" + filtro + "%");

            resultSet = statement.executeQuery();

            // Procesar los resultados
            while (resultSet.next()) {
                int idEquipo = resultSet.getInt("id_equipo");
                String modelo = resultSet.getString("modelo");
                String cpu = resultSet.getString("cpu");
                int discoDuro = resultSet.getInt("disco_duro");
                int ram = resultSet.getInt("ram");
                int potenciaFuente = resultSet.getInt("potencia_fuente");
                String factorForma = resultSet.getString("factor_forma");
                double precio = resultSet.getDouble("precio");

                // Crear el objeto Desktop y agregarlo a la lista
                Desktop desktop = new Desktop(idEquipo, modelo, cpu, discoDuro, ram, precio, potenciaFuente, factorForma);
                listaDesktops.add(desktop);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            // Cerrar recursos
            try {
                if (resultSet != null) resultSet.close();
                if (statement != null) statement.close();
                if (connection != null) connection.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return listaDesktops;
    }

    public void cargarLaptopsEnTabla(JTable table, String filtro) {

        // Subclase de DefaultTableModel para hacer la tabla no editable
        class NoEditableTableModel extends DefaultTableModel {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        }

        NoEditableTableModel model = new NoEditableTableModel();
        model.addColumn("ID");
        model.addColumn("Modelo");
        model.addColumn("CPU");
        model.addColumn("Disco Duro");
        model.addColumn("RAM");
        model.addColumn("Pantalla");
        model.addColumn("T�ctil");
        model.addColumn("Puertos USB");
        model.addColumn("Precio");

        List<Laptop> laptops = obtenerLaptops(filtro); // Usar el filtro

        for (Laptop laptop : laptops) {
            Object[] row = new Object[9];
            row[0] = laptop.getId();
            row[1] = laptop.getModelo();
            row[2] = laptop.getCpu();
            row[3] = laptop.getDiscoDuro();
            row[4] = laptop.getRam();
            row[5] = laptop.getPantalla();
            row[6] = laptop.isEsTactil() ? "S�" : "No"; // Mostrar "S�" o "No" para el valor booleano
            row[7] = laptop.getPuertosUsb();
            row[8] = laptop.getPrecio();
            model.addRow(row);
        }

        table.setModel(model);
    }
    
       public void cargarDesktopsEnTabla(JTable table, String filtro) {

        // Subclase de DefaultTableModel para hacer la tabla no editable
        class NoEditableTableModel extends DefaultTableModel {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        }

        NoEditableTableModel model = new NoEditableTableModel();
        model.addColumn("ID");
        model.addColumn("Modelo");
        model.addColumn("CPU");
        model.addColumn("Disco Duro");
        model.addColumn("RAM");
        model.addColumn("Potencia Fuente");
        model.addColumn("Factor Forma");
        model.addColumn("Precio");
        
        List<Desktop> desktops = obtenerDesktops(filtro); // Usar el filtro

        for (Desktop desktop : desktops) {
            Object[] row = new Object[8];
            row[0] = desktop.getId();
            row[1] = desktop.getModelo();
            row[2] = desktop.getCpu();
            row[3] = desktop.getDiscoDuro();
            row[4] = desktop.getRam();
            row[5] = desktop.getPotenciaFuente();
            row[6] = desktop.getFactorForma();
            row[7] = desktop.getPrecio();
            model.addRow(row);
        }

        table.setModel(model);
    }
   
    public Equipo obtenerEquipoPorId(int idEquipo) {
        String query = "SELECT * FROM Equipos WHERE id_equipo = ?";
        try (Connection connection = DatabaseConnection.getInstance().getConnection();
             PreparedStatement statement = connection.prepareStatement(query)) {

            statement.setInt(1, idEquipo);

            ResultSet resultSet = statement.executeQuery();

            if (resultSet.next()) {
                // Obtener los valores comunes
                String modelo = resultSet.getString("modelo");
                String cpu = resultSet.getString("cpu");
                int discoDuro = resultSet.getInt("disco_duro");
                int ram = resultSet.getInt("ram");
                double precio = resultSet.getDouble("precio");
                String categoria = resultSet.getString("categoria");

                // Dependiendo de la categor�a, crear el objeto correcto
                if ("laptop".equalsIgnoreCase(categoria)) {
                    // Obtener los campos espec�ficos de laptop
                    double pantalla = resultSet.getDouble("pantalla");
                    boolean esTactil = resultSet.getBoolean("es_tactil");
                    int puertosUsb = resultSet.getInt("puertos_usb");

                    // Retornar un objeto Laptop
                    return new Laptop(idEquipo,modelo, cpu, discoDuro, ram, precio, pantalla, esTactil, puertosUsb);
                    
                } else if ("desktop".equalsIgnoreCase(categoria)) {
                    // Obtener los campos espec�ficos de desktop
                    int potenciaFuente = resultSet.getInt("potencia_fuente");
                    String factorForma = resultSet.getString("factor_forma");

                    // Retornar un objeto Desktop
                    return new Desktop(idEquipo,modelo, cpu, discoDuro, ram, precio, potenciaFuente, factorForma);
                }
            }

        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return null;
    }
}
